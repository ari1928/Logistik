<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ClientPackage extends Model
{
    protected $guarded = [];
    protected $table = 'client_package';
    
}
