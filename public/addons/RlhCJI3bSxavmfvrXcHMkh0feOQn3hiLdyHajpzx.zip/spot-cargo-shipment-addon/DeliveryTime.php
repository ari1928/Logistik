<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DeliveryTime extends Model
{
    protected $guarded = [];
    protected $table = 'delivery_time';
}
